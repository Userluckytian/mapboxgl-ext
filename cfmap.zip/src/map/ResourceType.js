export const resourceType = [
  "Style",
  "SpriteJSON",
  "SpriteImage",
  "Tile",
  "Glyphs",
];
