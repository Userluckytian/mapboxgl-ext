var ATLAS_CONFIG = {
    api: 'http://api.atlasdata.cn',
    token: 'eyJpZCI6InNodW4ifQ.69ncA--qjdXrEXxMF3WDBlCKfLv_OigFLS27a2ATE_A',
};

var SDK_VERSION = '3.0.1';